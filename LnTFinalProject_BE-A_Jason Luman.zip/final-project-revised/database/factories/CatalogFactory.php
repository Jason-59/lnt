<?php

namespace Database\Factories;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Catalog>
 */
class CatalogFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'bookTitle' => $this->faker->sentence(mt_rand(3, 5)),
            'category_id' => mt_rand(1,3),
            'price' => mt_rand(10000, 1000000),
            'quantity' => mt_rand(0, 100),
        ];
    }
}
