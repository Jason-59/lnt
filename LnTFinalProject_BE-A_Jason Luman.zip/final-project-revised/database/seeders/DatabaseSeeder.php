<?php

namespace Database\Seeders;

use App\Models\Book;
use App\Models\User;
use App\Models\Catalog;
use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        User::create([
            'name' => 'John',
            'email' => 'john@gmail.com',
            'password' => Hash::make('password'),
            'ID_Admin' => 'Admin0001',
            'is_admin' => 1,
            'phoneNumber' => '081212121212',
            'address' => 'Jakarta, Indonesia',
            'postalCode' => 12134,
        ]);

        Category::create([
            'name' => 'Sci-Fi'
        ]);

        Category::create([
            'name' => 'Fantasy'
        ]);

        Category::create([
            'name' => 'Romance'
        ]);

        Book::factory(10)->create();

        Catalog::factory(10)->create();
    }
}
