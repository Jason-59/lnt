<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<div class="dashboard-content">
    <h1 class="dashboard-title">DASHBOARD</h1>

    <a href="<?php echo e(route('invoice')); ?>"><button class="justify-content-evenly badge bg-primary admin-tool"><i class="fa-solid fa-file-invoice me-2"></i>Generate Invoice</button></a>
</div>

<?php echo $__env->yieldContent('content'); ?><?php /**PATH E:\BNCC\LnT Class\final-project-revised\resources\views/dashboard.blade.php ENDPATH**/ ?>