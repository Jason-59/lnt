

<?php $__env->startSection('container'); ?>


<div class="d-flex justify-content-between">
    <h1>Library</h1>
    <a href="<?php echo e(route('create.book')); ?>"><button class="justify-content-evenly badge bg-primary admin-tool" style="width: 8rem">Add Books<i class="fas fa-plus ms-2"></i></button></a>
</div>

<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br>
<a href="/display-book/<?php echo e($book['id']); ?>"><h2>Book Title: <?php echo e($book['title']); ?></h2></a>
<p>Price: Rp.<?php echo e(number_format($book['price'], 0)); ?></p>
<p>Quantity: <?php echo e($book['quantity']); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BNCC\LnT Class\final-project-revised\resources\views/library.blade.php ENDPATH**/ ?>