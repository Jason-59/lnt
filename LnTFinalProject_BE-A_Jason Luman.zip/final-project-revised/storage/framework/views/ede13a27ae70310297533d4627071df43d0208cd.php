<?php $__env->startSection('container'); ?>
<h1 class="landing-title">Landing Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BNCC\LnT Class\final-project-revised\resources\views/welcome.blade.php ENDPATH**/ ?>