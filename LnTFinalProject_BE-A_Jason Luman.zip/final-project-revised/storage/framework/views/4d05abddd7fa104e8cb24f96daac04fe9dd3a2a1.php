<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="invoice-content">
    <div class="invoice-title d-flex align-items-lg-center mb-2">
        <i class="fa-solid fa-file-invoice me-2" style="font-size: 2.5rem"></i><h1>Invoice</h1>
    </div>

    <p class="mb-5">No: <?php echo e($noInvoice); ?></p>
    

    <div class="d-flex mb-3 mt-5 justify-content-between">
        <div class="invoice-right d-flex">
            <h6 style="width: 8rem">Name </h6>
            <h6 style="width: 1rem">:</h6>
            <h6><?php echo e($name); ?></h6>
        </div>
        <div class="invoice-left">
            <h6><?php echo e($todayDate); ?></h6>
        </div>
    </div>
    <div class="d-flex mb-3">
        <h6 style="width: 8rem">Address </h6>
        <h6 style="width: 1rem">:</h6>
        <h6><?php echo e($address); ?></h6>
    </div>
    <div class="d-flex mb-5">
        <h6 style="width: 8rem">Postal Code </h6>
        <h6 style="width: 1rem">:</h6>
        <h6><?php echo e($postalCode); ?></h6>
    </div>
    <table>
        <tr>
            <td><h6>Title</h6></td>
            <td><h6>Category</h6></td>
            <td><h6>Price</h6></td>
            <td><h6>Quantity</h6></td>
            <td><h6>SubTotal</h6></td>
        </tr>

    <?php for($i = 0; $i < $length; $i++): ?>
    <tr>
        <td><h6 style="font-weight: 200"><?php echo e($catalog[$i]->bookTitle); ?></h6></td>
        <td><h6 style="font-weight: 200"><?php echo e($catalog[$i]->name); ?></h6></td>
        <td><h6 style="font-weight: 200">Rp. <?php echo e(number_format($catalog[$i]->price)); ?></h6></td>
        <td><h6 style="font-weight: 200"><?php echo e($catalog[$i]->quantity); ?></h6></td>
        <td><h6 style="font-weight: 200">Rp. <?php echo e(number_format($catalog[$i]->price * $catalog[$i]->quantity)); ?></h6></td>
    </tr>
    <?php
        $grandTotal += $catalog[$i]->price * $catalog[$i]->quantity
    ?>
    <?php endfor; ?>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td><h6>Grand Total: </h6></td>
        <td><h6>Rp. <?php echo e(number_format($grandTotal)); ?></h6></td>
    </tr>
    </table>

    <div class="d-flex justify-content-end mt-5">
        <a href="/invoice-generate/<?php echo e($noInvoice); ?>" class="btn btn-warning invoice-btn"><i class="fa-solid fa-print"></i></a>
        <a href="/invoice-download/<?php echo e($noInvoice); ?>" class="btn btn-primary invoice-btn">Download</a>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?><?php /**PATH E:\BNCC\LnT Class\final-project-revised\resources\views/invoice.blade.php ENDPATH**/ ?>