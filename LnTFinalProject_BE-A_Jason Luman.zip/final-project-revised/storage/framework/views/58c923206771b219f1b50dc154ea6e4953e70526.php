

<?php $__env->startSection('container'); ?>


<div class="d-flex justify-content-between">
    <h1>Category</h1>
    <a href="<?php echo e(route('create.category')); ?>"><button class="justify-content-evenly badge bg-primary admin-tool"><i class="fa-solid fa-gear me-2"></i>Administrative Tools</button></a>
</div>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br>
<a><h4>Category Title: <?php echo e($category['name']); ?></h4></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BNCC\LnT Class\final-project-revised\resources\views/CategoryIndex.blade.php ENDPATH**/ ?>