<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\bookController;
use App\Http\Controllers\genreController;
use App\Http\Controllers\loginController;
use App\Http\Controllers\customerController;
use App\Http\Controllers\registerController;
use App\Http\Controllers\categoryController;
use App\Http\Controllers\catalogController;
use App\Http\Controllers\invoiceController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome', [
        'title' => 'Landing Page'
    ]);
});

Route::get('/home', function() {
    return view('dashboard', [
        'title' => 'Dashboard',
    ]);
})->name('dashboard')->middleware('auth');

//Book Controller
Route::controller(bookController::class)->group(function () {
    Route::get('/library', 'index')->name('library')->middleware('auth');
    Route::get('/create-book', 'createBook')->name('create.book');
    Route::POST('/store-book', 'store');
    Route::get('/display-book/{book:id}', 'display');
    Route::DELETE('/delete-book/{book:id}', 'delete');
    Route::get('/edit-book/{book:id}', 'edit');
    Route::PATCH('/update-book/{book:id}', 'update');
});

//Category Controller
Route::controller(categoryController::class)->group(function () {
    Route::get('/category', 'index')->name('category')->middleware('is_admin');
    Route::get('/create-category', 'createCategory')->name('create.category')->middleware('is_admin');
    Route::POST('/store-category', 'store')->middleware('is_admin');
});

//loginController
Route::controller(loginController::class)->group(function () {
    Route::get('/login', 'login')->name('login')->middleware('guest');
    Route::POST('/login', 'authenticate');
    Route::POST('/logout', 'logout')->middleware('auth');
    Route::get('/about', 'getData')->middleware('auth');
});

//registerController
Route::controller(registerController::class)->group(function () {
    Route::get('/register', 'register')->middleware('guest');
    Route::POST('/register', 'store');
});

Route::controller(catalogController::class)->group(function () {
    Route::get('/catalog', 'index')->name('catalog')->middleware('auth');
    Route::post('/store-catalog', 'store');
});

Route::controller(invoiceController::class)-> group(function () {
    Route::get('/invoice', 'index')->name('invoice')->middleware('auth');
    Route::get('/invoice-generate/{noInvoice}', 'viewPdf')->name('invoice-generate');
    Route::get('/invoice-download/{noInvoice}', 'downloadPdf')->name('invoice-download');
});
