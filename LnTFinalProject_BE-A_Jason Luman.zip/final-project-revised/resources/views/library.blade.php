@extends('layouts.main')

@section('container')


<div class="d-flex justify-content-between">
    <h1>Library</h1>
    <a href="{{route('create.book')}}"><button class="justify-content-evenly badge bg-primary admin-tool" style="width: 8rem">Add Books<i class="fas fa-plus ms-2"></i></button></a>
</div>

@foreach($books as $book)
<br>
<a href="/display-book/{{ $book['id'] }}"><h2>Book Title: {{ $book['title'] }}</h2></a>
<p>Price: Rp.{{ number_format($book['price'], 0) }}</p>
<p>Quantity: {{ $book['quantity'] }}</p>
@endforeach


@endsection