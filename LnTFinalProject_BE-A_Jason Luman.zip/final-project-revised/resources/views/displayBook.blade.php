@extends('layouts.main')

@section('container')


<img src="{{ asset('/storage/book_images/'.$book->image) }}" alt="{{ $book->title }} Cover" onerror="asset('/storage/book_images/Harry Potter-2.jpg')">
<h2>Book Title: {{ $book['title'] }}</h2>
<h3>Book Category: {{ $category }}</h3>
<p>Price: Rp.{{ number_format($book['price'], 0) }}</p>
<p>Quantity: {{ $book['quantity'] }}</p>

<form action="/delete-book/{{ $book->id }}" method = "POST">
@csrf
@method('DELETE')
<button type="submit" class="btn btn-danger" onclick = "return confirm('Are you sure you want to delete?')">Delete</button>
</form>

<a href="/edit-book/{{ $book->id }}"><button type="button" class="btn btn-warning mt-2">Edit</button></a>

@endsection