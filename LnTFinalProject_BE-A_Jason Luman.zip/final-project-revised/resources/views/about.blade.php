@extends('layouts.main')

@section('container')
<h1>About Page</h1>
<h3>Nama: {{ $name }}</h3>
<p>Email: {{ $email }}</p>
@endsection