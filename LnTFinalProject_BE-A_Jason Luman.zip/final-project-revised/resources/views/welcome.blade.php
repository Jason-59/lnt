@extends('layouts.main')

@section('container')
<h1 class="landing-title">Landing Page</h1>
@endsection