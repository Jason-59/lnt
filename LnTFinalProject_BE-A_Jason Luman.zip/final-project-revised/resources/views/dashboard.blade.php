@include('layouts.main')

@section('content')

<div class="dashboard-content">
    <h1 class="dashboard-title">DASHBOARD</h1>

    <a href="{{route('invoice')}}"><button class="justify-content-evenly badge bg-primary admin-tool"><i class="fa-solid fa-file-invoice me-2"></i>Generate Invoice</button></a>
</div>

@yield('content')