@extends('layouts.main')

@section('container')


<div class="d-flex justify-content-between">
    <h1>Category</h1>
    <a href="{{route('create.category')}}"><button class="justify-content-evenly badge bg-primary admin-tool"><i class="fa-solid fa-gear me-2"></i>Administrative Tools</button></a>
</div>

@foreach($categories as $category)
<br>
<a><h4>Category Title: {{ $category['name'] }}</h4></a>
@endforeach


@endsection