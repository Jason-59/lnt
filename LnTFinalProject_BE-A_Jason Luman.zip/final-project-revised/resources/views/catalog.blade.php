@include('layouts.main')

@section('content')

<div class="catalog-content">
    <h1 class="catalog-title mb-5">Catalog</h1>

    <form action = "/store-catalog" method = "POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Book Title</label>
          <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name = "title" value = "{{ old('title') }}" style="height: : 20px; width: 87rem">
          @error('title')
          <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Book Category</label>
          <select type="text" class="form-select" id="exampleInputEmail1" aria-describedby="emailHelp" name = "categoryName" value = "{{ old('title') }} " style="height: : 20px; width: 87rem">
            <option selected>Open this Select Menu</option>
            @foreach($categories as $category)
            <option value="{{ $category->id }}">{{ $category->name }}</option>
            @endforeach
          </select>
          @error('title')
          <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Price</label>
          <div class="d-flex">
              <p class="mt-2 me-2" style="height: 20px">Rp. </p>
              <input type="text" class="form-control" id="exampleInputPassword1" name = "price" value = "{{ old('price') }}" style="height: : 20px; width: 85rem">
          </div>
          @error('price')
          <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Quantity</label>
          <input type="text" class="form-control" id="exampleInputPassword1" name = "quantity" value = "{{ old("quantity") }}" style="height: : 20px; width: 87rem">
          @error('quantity')
          <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Book Cover</label>
          <input type="file" class="form-control" id="exampleInputPassword1" name = "image" value = "{{ old("image") }}" style="height: : 20px; width: 87rem">
          @error('image')
          <div class="alert alert-danger">{{ $message }}</div>
          @enderror
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

@yield('content')