@extends('layouts.main')


@section('container')
<h1 class="mb-4">Login</h1>

<div class="login-choice">
  <button id="user-btn" class="login-choice-btn login-choice-btn-changed">User</button>
  <button id="admin-btn" class="admin-btn login-choice-btn">Admin</button>
</div>

<form action = "/login" method = "POST">
    @csrf
    <div class="mb-3 ID_Admin_input display-none">
      <label for="ID_Admin" class="form-label">ID Amin</label>
      <input type="ID_Admin" class="form-control" id="ID_Admin" aria-describedby="ID_AdminHelp" name = "ID_Admin" value = "{{ old('ID_Admin') }}">
      @error('email')
      <div class="alert alert-danger">{{ $message }}</div>
      @enderror
    </div>
    <div class="mb-3">
      <label for="email" class="form-label">E-mail</label>
      <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name = "email" value = "{{ old('email') }}">
      @error('email')
      <div class="alert alert-danger">{{ $message }}</div>
      @enderror
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">Password</label>
      <input type="password" class="form-control" id="password" name = "password" value = "{{ old('password') }}">
      @error('password')
      <div class="alert alert-danger">{{ $message }}</div>
      @enderror
    </div>
    <input type="hidden" name="loginType" value="false" id="login-type">
    <button type="submit" class="btn btn-primary">Login</button>
    <small class="mt-3" style="display:block">Don't have an account yet? <a href="/register">Register Here!</a></small>
</form>

@endsection