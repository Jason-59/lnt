let a = document.querySelectorAll('.login-choice-btn');
a.forEach((el) => {
    el.addEventListener('click', () => {
        for (let i = 0; i < a.length; i++)
        {
            a[i].classList.remove('login-choice-btn-changed');
        }
        el.classList.add('login-choice-btn-changed');
    })
});

let b = document.querySelector('#login-type');
let c = document.querySelector('.ID_Admin_input');
document.querySelector('#user-btn').addEventListener('click', () => {
    b.value = false;
    c.classList.add('display-none');
})

document.querySelector('#admin-btn').addEventListener('click', () => {
    b.value = true;
    c.classList.remove('display-none');
})
