<?php

namespace App\Http\Controllers;

use App\Models\Catalog;
use App\Models\Category;
use Illuminate\Http\Request;

class catalogController extends Controller
{
    public function index() {
        $category = Category::all();
        return view('catalog', [
            'title' => 'Catalog',
            'categories' => $category,
        ]);
    }

    public function store(Request $request) {
        $request->validate([
            'title' => 'required|min:5|max:80',
            'categoryName' => 'required',
            'price' => 'required|regex:/^[\d]+/',
            'quantity' => 'required|regex:/^[\d]+/',
            'image' => 'required'
        ]);

        $extension = $request->file('image')->getClientOriginalExtension();
        $filename = $request->title.'-'.$request->category_id.'.'.$extension;
        $request->file('image')->storeAs('/public/book_images', $filename);
        Catalog::create([
            'bookTitle' => $request->title,
            'categoryName' => $request->categoryName,
            'price' => $request->price,
            'quantity' => $request->quantity,
            'image' => $filename
        ]);

        return redirect(route('catalog'));
    }
}
