<?php

namespace App\Http\Controllers;

use Auth;
use App\Models\User;
use App\Models\Catalog;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;

class invoiceController extends Controller
{
    public function index() {
        $catalogs = Catalog::all();

        $length = $catalogs->count();
        $catalog_categories = DB::table('catalogs')
                            ->leftJoin('categories', 'catalogs.category_id', '=', 'categories.id')
                            ->get();
        
        $catalog = $catalog_categories->toJson();
        $cat = json_decode($catalog);
       
        return view('invoice', [
            'title' => 'Invoice',
            'noInvoice' => mt_rand(1, 999999999999),
            'catalog' => $cat,
            'length' => $length,
            'grandTotal' => 0,
            'name' => auth()->user()->name,
            'address' => auth()->user()->address,
            'postalCode' => auth()->user()->postalCode,
            'todayDate' => Carbon::now()->format('l jS \of F Y h:i:s A'),
        ]);
    }

    public function viewPdf(int $noInvoice) {
        $catalogs = Catalog::all();

        $length = $catalogs->count();
        $catalog_categories = DB::table('catalogs')
                            ->leftJoin('categories', 'catalogs.category_id', '=', 'categories.id')
                            ->get();
        
        $catalog = $catalog_categories->toJson();
        $cat = json_decode($catalog);

        $data = [
            'title' => 'Invoice',
            'noInvoice' => $noInvoice,
            'catalog' => $cat,
            'length' => $length,
            'grandTotal' => 0,
            'name' => auth()->user()->name,
            'address' => auth()->user()->address,
            'postalCode' => auth()->user()->postalCode,
            'todayDate' => Carbon::now()->format('l jS \of F Y h:i:s A'),
        ];
        
        $pdf = Pdf::loadView('invoice-generate', $data);
        return $pdf->stream("Invoice.pdf");
    }

    public function downloadPdf(int $noInvoice) {
        $catalogs = Catalog::all();

        $length = $catalogs->count();
        $catalog_categories = DB::table('catalogs')
                            ->leftJoin('categories', 'catalogs.category_id', '=', 'categories.id')
                            ->get();
        
        $catalog = $catalog_categories->toJson();
        $cat = json_decode($catalog);

        $data = [
            'title' => 'Invoice',
            'noInvoice' => $noInvoice,
            'catalog' => $cat,
            'length' => $length,
            'grandTotal' => 0,
            'name' => auth()->user()->name,
            'address' => auth()->user()->address,
            'postalCode' => auth()->user()->postalCode,
            'todayDate' => Carbon::now()->format('l jS \of F Y h:i:s A'),
        ];

        
        $pdf = Pdf::loadView('invoice-generate', $data);
        return $pdf->download("Invoice.pdf");
    }
}
