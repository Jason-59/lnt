<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class bookController extends Controller
{
    public function createBook(){
        $category = Category::all();

        return view('createBook', [
            'title' => 'Create Book',
            'categories' => $category
        ]);
    }

    public function store(Request $request){

        $request->validate([
            'title' => 'required|min:5|max:80',
            'category_id' => 'required',
            'price' => 'required',
            'quantity' => 'required',
            'image' => 'required'
        ]);

        $extension = $request->file('image')->getClientOriginalExtension();
        $filename = $request->title.'-'.$request->category_id.'.'.$extension;
        $request->file('image')->storeAs('/public/book_images', $filename);
        Book::create([
            'title' => $request->title,
            'category_id' => $request->category_id,
            'price' => $request->price,
            'quantity' => $request->quantity,
            'image' => $filename
        ]);

        return redirect('/library');
    }

    public function index(){
        $books = Book::all();

        return view('library', [
            'title' => 'Library',
            'books' => $books
        ]);
    }

    public function display(Book $book){
        // $book = Book::findOrFail($id);
        $category = DB::table('books')
                ->leftJoin('categories', 'books.category_id', '=', 'categories.id')
                ->where('title', '=', $book->title)
                ->get();
        return view('displayBook', [
            'title' => 'Book Display',
            'category' => $category->first()->name,
            'book' => $book           
        ]);
    }

    public function delete(Book $book){
        $book->delete();
        return redirect('/library');
    }

    public function edit(Book $book){
        return view('editBook', [
            'title' => 'Edit Book',
            'book' => $book
        ]);
    }

    public function update(Book $book, Request $request){
        $request->validate([
            'title' => 'required|min:5|max:80',
            'price' => 'required',
            'quantity' => 'required'
        ]);

        $book->update([
            'title' => $request->title,
            'price' => $request->price,
            'quantity' => $request->quantity
        ]);

        return redirect('/library');
    }
}


