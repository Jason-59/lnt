<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class registerController extends Controller
{
    public function register(){
        return view('register.index',[
            'title' => 'register'
        ]);
    }

    public function store(Request $request){
        $validatedData = $request->validate([
            'name' => ['required', 'min:3', 'max:40'],
            'email' => ['required', 'unique:users', 'regex:/^([a-z\d\.-]+)@gmail\.com$/'],
            'password' => ['required', 'min:6', 'max:12'],
            'phoneNumber' => ['required', 'regex:/^(08)/'],
            'address' => ['required', 'min:10', 'max:100'],
            'postalCode' => ['required', 'regex:/^[\d]{5}$/']
        ]);

        $validatedData['password'] = Hash::make($validatedData['password']);

        User::create($validatedData);

        return redirect('/login');
    }
}
